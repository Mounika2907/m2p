import React, { Component } from 'react';
import Aux from '../../../hoc/Aux';

class Register extends Component {
    render() {
        return (
            <Aux>
                Register
            </Aux>
        )
    }
}

export default Register;
