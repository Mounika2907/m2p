import React, { Component } from 'react';
import Aux from '../../hoc/Aux';

class Home extends Component {
    render() {
        return (
            <Aux>
                Home
            </Aux>
        )
    }
}

export default Home;
