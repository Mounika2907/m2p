import React, { Component } from 'react'
import Aux from '../../hoc/Aux'

class Chat extends Component {
    render() {
        return (
            <Aux>

            </Aux>
        )
    }
}

export default Chat;
