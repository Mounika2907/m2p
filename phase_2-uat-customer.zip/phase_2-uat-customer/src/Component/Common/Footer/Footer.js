import React from 'react'
import Aux from '../../../hoc/Aux';

const Footer = () => {
    return (
        <Aux>
            Footer
        </Aux>
    )
}

export default Footer;
